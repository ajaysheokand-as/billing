<!DOCTYPE html>
<html>
<head>
	<title>Test</title>
	 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
</head>
<body>
<?php 
include('footer.php');
 ?>
 <footer>
<div class="footer">
	

	 <div class="row my-row" style="background-color: #b2b5b8; height: 50px;">
	 	<div class="col my-col" style="text-align: center; margin-top: 10px; font-size: 17px; font-weight: bold; color: white;">
	 	All copyright@AJAY SHEOKAND	
	 	</div>
		
	 </div>

 </div>
 </footer>
</body>
</html>