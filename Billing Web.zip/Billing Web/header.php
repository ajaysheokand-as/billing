 <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#"><h1> <i class="fas fa-book"></i> Digital Billing</h1></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto" style="font-size: 18px; font-weight: bold; border-radius: 5px;  ">
      <li class="nav-item active">
        <a class="nav-link" href="index.php" style="border-radius: 5px; border: 1px solid; margin: 10px; width: 100px;" ><i class="fas fa-home"></i>  Home </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="log_in.php" style="border-radius: 5px; border: 1px solid; margin: 10px; width: 100px;"> <i class="fas fa-sign-in-alt"></i> Login</a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="createAcc.php" style="border-radius: 5px; border: 1px solid; margin:10px; width: 100px;"> <i class="fas fa-plus"></i>   Sign In</a>
      </li>
     
     
    </ul>
   
  </div>
</nav>